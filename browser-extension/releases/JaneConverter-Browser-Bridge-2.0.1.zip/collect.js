(() => {
  if (window.__janeConverterCollectMode__) return;
  const state = {
    enabled: false,
    busy: false,
    timer: null,
    observer: null,
    lastKeys: new Set(),
    fingerprints: [],
    stopCapture: null
  };
  window.__janeConverterCollectMode__ = state;

  const MAX_BYTES = 64 * 1024 * 1024;
  const MAX_VIDEO_MS = 30 * 1000;

  function visible(element) {
    const rect = element.getBoundingClientRect();
    const style = getComputedStyle(element);
    const area = Math.max(0, rect.width) * Math.max(0, rect.height);
    return style.display !== "none"
      && style.visibility !== "hidden"
      && style.opacity !== "0"
      && rect.bottom > 0
      && rect.right > 0
      && rect.top < innerHeight
      && rect.left < innerWidth
      && area > 4
      ? { rect: rect, area: area }
      : null;
  }

  function isPrimary(element, geometry) {
    const tag = element.tagName.toLowerCase();
    const playing = tag === "video" && !element.paused && element.readyState >= 2;
    return playing
      || geometry.area >= Math.max(96000, innerWidth * innerHeight * 0.10)
      || geometry.rect.width >= innerWidth * 0.32
      || geometry.rect.height >= innerHeight * 0.32;
  }

  function currentUrl(element) {
    const source = element.querySelector && element.querySelector("source[src]");
    return element.currentSrc || element.src || (source && source.src) || "";
  }

  function candidates() {
    const found = [];
    const seen = new Set();
    const visit = function (root) {
      if (!root || typeof root.querySelectorAll !== "function") return;
      for (const element of root.querySelectorAll("video, img, canvas")) {
        if (seen.has(element)) continue;
        seen.add(element);
        const geometry = visible(element);
        if (!geometry || !isPrimary(element, geometry)) continue;
        const tag = element.tagName.toLowerCase();
        const playing = tag === "video" && !element.paused && element.readyState >= 2;
        found.push({ element: element, geometry: geometry, playing: playing, tag: tag });
        if (element.shadowRoot) visit(element.shadowRoot);
      }
      for (const element of root.querySelectorAll("*")) {
        if (element.shadowRoot) visit(element.shadowRoot);
      }
    };
    visit(document);
    return found.sort(function (left, right) {
      return Number(right.playing) - Number(left.playing)
        || right.geometry.area - left.geometry.area;
    });
  }

  function keyFor(candidate) {
    const element = candidate.element;
    const url = currentUrl(element);
    const visual = (candidate.tag === "canvas" || (candidate.tag === "video" && !url))
      ? visualHashForElement(element) || ""
      : "";
    return [candidate.tag, url, element.videoWidth || element.naturalWidth || element.width, element.videoHeight || element.naturalHeight || element.height, visual].join("|");
  }

  function visualHashForElement(element) {
    if (!globalThis.JaneMediaUtils) return null;
    try {
      const sample = document.createElement("canvas");
      sample.width = 9;
      sample.height = 8;
      const context = sample.getContext("2d", { willReadFrequently: true });
      context.drawImage(element, 0, 0, 9, 8);
      return globalThis.JaneMediaUtils.visualHashFromPixels(context.getImageData(0, 0, 9, 8).data);
    } catch (_) {
      return null;
    }
  }

  async function visualHashForBlob(blob) {
    if (typeof createImageBitmap !== "function" || !globalThis.JaneMediaUtils) return null;
    try {
      const image = await createImageBitmap(blob);
      try { return visualHashForElement(image); } finally { image.close(); }
    } catch (_) {
      return null;
    }
  }

  function fingerprintFor(candidate, contentHash) {
    const element = candidate.element;
    const rect = candidate.geometry.rect;
    const position = element.closest && element.closest("[aria-posinset]");
    const index = position && Number(position.getAttribute("aria-posinset"));
    return {
      site: location.hostname,
      kind: candidate.tag === "video" ? "video" : "image",
      width: element.videoWidth || element.naturalWidth || element.width || 0,
      height: element.videoHeight || element.naturalHeight || element.height || 0,
      surface: [rect.left, rect.top, rect.width, rect.height].map(function (value) { return Math.round(value / 32); }).join(":"),
      duration: candidate.tag === "video" && Number.isFinite(element.duration) ? Math.round(element.duration * 2) / 2 : 0,
      sequenceIndex: Number.isInteger(index) && index > 0 ? index : null,
      contentHash: contentHash,
      url: currentUrl(element)
    };
  }

  async function encodeBlob(blob, fileName, captureMethod = "rendered") {
    if (!blob || !blob.size || blob.size > MAX_BYTES) throw new Error("The rendered capture is empty or larger than 64 MB.");
    const bytes = new Uint8Array(await blob.arrayBuffer());
    let binary = "";
    for (let offset = 0; offset < bytes.length; offset += 0x8000) {
      binary += String.fromCharCode.apply(null, bytes.subarray(offset, Math.min(offset + 0x8000, bytes.length)));
    }
    return {
      contentHash: await globalThis.JaneMediaUtils.contentHash(bytes),
      captureMethod,
      base64: btoa(binary),
      contentType: blob.type || "application/octet-stream",
      fileName: fileName,
      mediaKind: blob.type.startsWith("image/") ? "image" : blob.type.startsWith("audio/") ? "audio" : "video",
      pageUrl: location.href,
      title: document.title || "Collected browser media"
    };
  }

  async function captureImage(candidate) {
    const element = candidate.element;
    const width = element.naturalWidth || element.videoWidth || element.width;
    const height = element.naturalHeight || element.videoHeight || element.height;
    if (!width || !height) throw new Error("The story image has not finished loading.");
    const canvas = document.createElement("canvas");
    canvas.width = width;
    canvas.height = height;
    let blob;
    try {
      const context = canvas.getContext("2d");
      if (!context) throw new Error("The browser could not create a rendered image surface.");
      context.drawImage(element, 0, 0, width, height);
      blob = await new Promise(function (resolve) { canvas.toBlob(resolve, "image/png"); });
    } catch (_) {}
    if (blob) {
      return { payload: await encodeBlob(blob, "browser-collect-" + Date.now() + ".png"), visualHash: visualHashForElement(canvas) };
    }
    const source = currentUrl(element);
    if (!source || !/^https?:/i.test(source)) throw new Error("The browser protected the rendered story image.");
    const response = await globalThis.JaneMediaUtils.fetchBounded(source, { credentials: "include", cache: "no-store" }, 8000, MAX_BYTES);
    if (!response.ok) throw new Error("The story image could not be read.");
    blob = await response.blob();
    return { payload: await encodeBlob(blob, "browser-collect-" + Date.now() + ".png", "page-fetch"), visualHash: await visualHashForBlob(blob) };
  }

  async function captureVideo(candidate) {
    const element = candidate.element;
    if (!candidate.playing) throw new Error("Start the story video before collect mode captures it.");
    const captureStream = element.captureStream || element.mozCaptureStream;
    if (typeof captureStream !== "function" || typeof MediaRecorder === "undefined") {
      throw new Error("This browser does not expose rendered story video frames.");
    }
    const mimeType = ["video/webm;codecs=vp9,opus", "video/webm;codecs=vp8,opus", "video/webm"]
      .find(function (value) { return !MediaRecorder.isTypeSupported || MediaRecorder.isTypeSupported(value); });
    if (!mimeType) throw new Error("This browser cannot record the story video format.");
    const visualHash = visualHashForElement(element);
    const stream = captureStream.call(element);
    const recorder = new MediaRecorder(stream, { mimeType: mimeType });
    const chunks = [];
    let recordedBytes = 0;
    const result = await new Promise(function (resolve, reject) {
      let timer;
      let hardTimer;
      let settled = false;
      const finish = function (callback, value) {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        clearTimeout(hardTimer);
        state.stopCapture = null;
        if (recorder.state !== "inactive") recorder.stop();
        stream.getTracks().forEach((track) => track.stop());
        recorder.removeEventListener("dataavailable", onData);
        recorder.removeEventListener("stop", onStop);
        recorder.removeEventListener("error", onError);
        element.removeEventListener("ended", stop);
        callback(value);
      };
      const onData = function (event) {
        if (!event.data || !event.data.size) return;
        recordedBytes += event.data.size;
        if (recordedBytes > MAX_BYTES) {
          stop();
          finish(reject, new Error("The rendered capture exceeded 64 MB."));
          return;
        }
        chunks.push(event.data);
      };
      const onError = function () { finish(reject, new Error("The browser could not record the story video.")); };
      const onStop = async function () {
        const blob = new Blob(chunks, { type: mimeType });
        if (!blob.size) {
          finish(reject, new Error("The browser returned no rendered story frames."));
          return;
        }
        try {
          finish(resolve, await encodeBlob(blob, "browser-collect-" + Date.now() + ".webm"));
        } catch (error) {
          finish(reject, error);
        }
      };
      const stop = function () { if (recorder.state !== "inactive") recorder.stop(); };
      state.stopCapture = stop;
      recorder.addEventListener("dataavailable", onData);
      recorder.addEventListener("stop", onStop);
      recorder.addEventListener("error", onError);
      element.addEventListener("ended", stop, { once: true });
      timer = setTimeout(stop, MAX_VIDEO_MS);
      hardTimer = setTimeout(function () { finish(reject, new Error("Rendered capture deadline reached.")); }, MAX_VIDEO_MS + 5000);
      recorder.start(250);
    });
    return { payload: result, visualHash: visualHash };
  }

  async function captureCandidate(candidate) {
    return candidate.tag === "video" ? captureVideo(candidate) : captureImage(candidate);
  }

  async function scan() {
    if (!state.enabled || state.busy) return;
    const candidate = candidates()[0];
    if (!candidate) return;
    const key = keyFor(candidate);
    if (key && state.lastKeys.has(key)) return;
    // A reused media URL cannot establish that a story is unchanged.
    state.busy = true;
    try {
      const captured = await captureCandidate(candidate);
      if (!state.enabled) return;
      const fingerprint = fingerprintFor(candidate, captured.payload.contentHash);
      state.fingerprints = state.fingerprints.filter(function (previous) {
        return Date.now() - previous.capturedAt < 2 * 60 * 1000;
      });
      if (globalThis.JaneMediaUtils && state.fingerprints.some(function (previous) {
        return globalThis.JaneMediaUtils.sameStoryFingerprint(previous.value, fingerprint);
      })) {
        state.lastKeys.add(key);
        if (state.lastKeys.size > 48) state.lastKeys.delete(state.lastKeys.values().next().value);
        return;
      }
      const accepted = await new Promise(function (resolve) {
        const deadline = setTimeout(function () { resolve(false); }, 60000);
        chrome.runtime.sendMessage({ type: "jane-collect-media", payload: captured.payload }, function (response) {
          clearTimeout(deadline);
          resolve(!chrome.runtime.lastError && Boolean(response && response.ok));
        });
      });
      if (!accepted) return;
      state.lastKeys.add(key);
      if (state.lastKeys.size > 48) state.lastKeys.delete(state.lastKeys.values().next().value);
      state.fingerprints.push({ value: fingerprint, capturedAt: Date.now() });
      if (state.fingerprints.length > 48) state.fingerprints.shift();
    } catch (_) {
      // Keep watching. A protected or paused item should not stop later story pages.
    } finally {
      state.busy = false;
    }
  }

  let debounceTimer = null;

  function stopWatching() {
    if (debounceTimer) {
      clearTimeout(debounceTimer);
      debounceTimer = null;
    }
    if (state.stopCapture) state.stopCapture();
    if (state.timer) clearInterval(state.timer);
    state.timer = null;
    if (state.observer) state.observer.disconnect();
    state.observer = null;
  }

  function startWatching() {
    stopWatching();
    state.timer = setInterval(function () { void scan(); }, 900);
    state.observer = new MutationObserver(function () {
      if (debounceTimer) clearTimeout(debounceTimer);
      debounceTimer = setTimeout(function () { void scan(); }, 250);
    });
    if (document.documentElement) state.observer.observe(document.documentElement, { childList: true, subtree: true, attributes: true, attributeFilter: ["src", "poster", "class", "style"] });
    void scan();
  }

  chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
    if (!message || message.type !== "jane-collect-control") return false;
    state.enabled = Boolean(message.enabled);
    if (state.enabled) {
      startWatching();
      chrome.runtime.sendMessage({ type: "jane-collect-status", enabled: true });
    } else {
      stopWatching();
      chrome.runtime.sendMessage({ type: "jane-collect-status", enabled: false });
    }
    sendResponse({ ok: true, enabled: state.enabled });
    return true;
  });
})();
